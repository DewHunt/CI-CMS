<style type="text/css">
    .parentMenuBlock{
        border: 1px solid #d4c8c8;
        padding: 10px 0px;
        margin-bottom: 10px;
    }
</style>