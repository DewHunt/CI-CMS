<div class="row">
    <div class="col-md-8">
        <label for="name">Name</label>
        <div class="form-group">
            <input type="text" class="form-control form-control-danger" placeholder="Name" name="name" value="" required>
        </div>
    </div>

    <div class="col-md-4">
        <label for="order-by">Order By</label>
        <div class="form-group">
            <input type="number" min="1" class="form-control form-control-danger" placeholder="Order By" name="orderBy" value="">
        </div>
    </div>
</div>