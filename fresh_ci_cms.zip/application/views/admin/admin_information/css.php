<style type="text/css">
	.head_name {
		font-weight: bold;
		width: 170px;
	}

	.head_colon {
		font-weight: bold;
		width: 10px;
	}

	.image_title {
		font-weight: bold;
	}
</style>