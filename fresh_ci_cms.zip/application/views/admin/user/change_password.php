<div class="row">
	<input class="form-control" type="hidden" name="userId" value="<?= $userId ?>">
    <div class="col-md-12">
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" class="form-control" name="password" value="" placeholder="Password" required>
        </div>                                        
    </div>
</div>