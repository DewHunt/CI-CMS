
        <!-- Preloader - style you can find in spinners.css -->
        <div class="preloader">
            <div class="loader">
                <div class="loader__figure"></div>
                <p class="loader__label">Dew Hunt</p>
            </div>
        </div>