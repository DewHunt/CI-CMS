<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class User extends Admin_Controller {

    public function __construct()
    {
        parent:: __construct();
        $this->load->library('form_validation');
        // $this->load->helper('settings_helper');
        $this->load->helper('file');
        $this->load->model('UserModel');
        
        if (empty($this->session->userdata('sessionUserInfo'))) {
            redirect(base_url('login'));
        }
    }

    public function Index()
    {
        if (empty($this->session->userdata('sessionUserInfo')) || empty($this->LinkModel->IndexLink())) {
            redirect(base_url('login'));
        } else {
            $allUsers = $this->UserModel->GetAllUsers();

            $this->data['title'] = "User";
            $this->contentData['allUsers'] = $allUsers;

            $this->cardBodyContent = $this->load->view('admin/user/index', $this->contentData, TRUE);

            $this->load->view('admin/master/master_index', $this->data);
        }
    }

    public function Add()
    {
        if (empty($this->session->userdata('sessionUserInfo')) || empty($this->LinkModel->AddLink())) {
            redirect(base_url('login'));
        } else {
        	$allUserRoles = $this->HelperModel->GetAllData('tbl_user_roles','name','ASC');

            $this->data['title'] = "Add New User";
            $this->data['formLink'] = "user/save/";
            $this->data['buttonName'] = "Save";

            $this->contentData['allUserRoles'] = $allUserRoles;

            $this->cardBodyContent = $this->load->view('admin/user/add', $this->contentData, TRUE);

            $this->load->view('admin/master/master_add_edit', $this->data);
        }
    }

    public function Save()
    {
        if (empty($this->session->userdata('sessionUserInfo')) || empty($this->LinkModel->AddLink())) {
            redirect(base_url('login'));
        } else {
            // echo "<pre>"; print_r($this->input->post()); exit();
            $userName = $this->input->post('username');
            $email = $this->input->post('email');

        	$isExists = $this->UserModel->CheckUserDuplicity($userName,$email);

        	if ($isExists) {
        		$this->session->set_flashdata('error', 'User Name Or Email Already Exists.');
        		redirect(base_url('user/add'));
        	} else {
                $imagePath = $this->UploadImage('userImage',500,'user/add','/public/uploads/user_images/');
                // echo "<pre>"; print_r($imagePath); exit();

                $data = array(
                    'name' => trim($this->input->post('name')),
                    'email' => $email,
                    'user_name' => $userName,
                    'image' => $imagePath,
                    'role' => trim($this->input->post('role')),
                    'password' => sha1(trim($this->input->post('password'))),
                );

                $this->db->insert('tbl_users', $data);
        		$this->session->set_flashdata('message', 'User Save Successfully.');
        		redirect(base_url('user'));
        	}
        }
    }

    public function Edit($userId)
    {
        if (empty($this->session->userdata('sessionUserInfo')) || empty($this->LinkModel->EditLink())) {
            redirect(base_url('login'));
        } else {
            $userInfo = $this->HelperModel->GetDataById('tbl_users',$userId);
        	$allUserRoles = $this->HelperModel->GetAllData('tbl_user_roles','name','ASC');

            $this->data['title'] = "Edit User";
            $this->data['formLink'] = "user/update/";
            $this->data['buttonName'] = "Update";

            $this->contentData['userInfo'] = $userInfo;
            $this->contentData['allUserRoles'] = $allUserRoles;

            $this->cardBodyContent = $this->load->view('admin/user/edit', $this->contentData, TRUE);
            
            $this->load->view('admin/master/master_add_edit', $this->data);
        }
    }

    public function Update()
    {
        if (empty($this->session->userdata('sessionUserInfo')) || empty($this->LinkModel->EditLink())) {
            redirect(base_url('login'));
        } else {
        	// echo "<pre>";
        	// print_r($this->input->post()); exit();

        	$id = $this->input->post('id');
        	$isExists = $this->HelperModel->CheckDataDuplicityByFieldAndId($tableName,$fieldName,$data,$id);

        	if ($isExists) {
        		$this->session->set_flashdata('error', 'Data Already Exists.');
        		redirect(base_url('user/edit/'.$id));
        	} else {
                $data = array(
                    'field_name' => trim($this->input->post('inputName')),
                );

                $this->db->where('id',$id);
                $this->db->update($tableName, $data);
        		$this->session->set_flashdata('message', 'Data Updated Successfully.');
        		redirect(base_url('user'));
        	}
        }
    }

    public function Profile($userId)
    {
        if (empty($this->session->userdata('sessionUserInfo')) || empty($this->LinkModel->ViewLink())) {
            redirect(base_url('login'));
        } else {
            $userInfo = $this->UserModel->GetUserInfoById($userId);
            // echo "<pre>"; print_r($userInfo); exit();

            $this->data['title'] = "User Profile";

            $this->contentData['title'] = "User Profile";
            $this->contentData['userInfo'] = $userInfo;
            // echo "<pre>"; print_r($this->contentData['data']); exit();

            // $this->customCss = $this->load->view('admin/user/css', '', TRUE);
            $this->cardContent = $this->load->view('admin/user/profile', $this->contentData, TRUE);

            $this->load->view('admin/master/master', $this->data);
        }
    }

    public function Delete()
    {
        if (empty($this->session->userdata('sessionUserInfo')) || empty($this->LinkModel->DeleteLink())) {
            redirect(base_url('login'));
        } else {
        	$id = $this->input->post('id');
        	$this->db->delete('tbl_users', array('id' => $id));
        }
    }

    public function Status()
    {
        if (empty($this->session->userdata('sessionUserInfo')) || empty($this->LinkModel->StatusLink())) {
            redirect(base_url('login'));
        } else {
            $id = $this->input->post('id');
            $this->HelperModel->UpdateStatus('tbl_users',$id);
        }
    }
}
